/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application's scene delegate.
*/

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

}

