# Customizing Scribble with Interactions

Enable writing on a non-text-input view by adding interactions.

## Overview

- Note: This sample code project is associated with WWDC20 session [10106: Meet Scribble for iPad](https://developer.apple.com/wwdc20/10106/).

This sample code project must be run on a physical device with Apple Pencil.
